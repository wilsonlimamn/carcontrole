const { getDefaultConfig } = require('expo/metro-config');
const path = require('path');

const config = getDefaultConfig(__dirname);

config.watchFolders = [__dirname];

config.resolver.blockList = [
  new RegExp(path.resolve(__dirname, '.local') + '/.*'),
  new RegExp(path.resolve(__dirname, 'car-controle') + '/.*'),
];

module.exports = config;
