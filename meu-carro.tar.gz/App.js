import React, {
  useState,
  useCallback,
  useEffect,
  memo
} from 'react';

import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  TextInput,
  FlatList,
  Alert,
  ScrollView
} from 'react-native';

import AsyncStorage from '@react-native-async-storage/async-storage';

import {
  MaterialCommunityIcons,
  FontAwesome5
} from '@expo/vector-icons';

/* ======================================================
   ITENS MENU
====================================================== */

const itens = [

  {
    id: '1',
    nome: 'Óleo',
    icone: 'oil',
    biblioteca: 'MaterialCommunityIcons',
    cor: '#e67e22'
  },

  {
    id: '2',
    nome: 'Filtros',
    icone: 'air-filter',
    biblioteca: 'MaterialCommunityIcons',
    cor: '#27ae60'
  },

  {
    id: '3',
    nome: 'Alinhamento e Balanceamento',
    icone: 'car-cog',
    biblioteca: 'MaterialCommunityIcons',
    cor: '#2980b9'
  },

  {
    id: '4',
    nome: 'Pneus',
    icone: 'car-side',
    biblioteca: 'FontAwesome5',
    cor: '#c0392b'
  },

  {
    id: '5',
    nome: 'Bateria',
    icone: 'car-battery',
    biblioteca: 'FontAwesome5',
    cor: '#f1c40f'
  },

  {
    id: '6',
    nome: 'Correias',
    icone: 'engine',
    biblioteca: 'MaterialCommunityIcons',
    cor: '#9b59b6'
  }

];

/* ======================================================
   INPUT
====================================================== */

const TextInputField = memo(({
  value,
  setValue,
  placeholder
}) => {

  return (

    <TextInput
      value={value}
      onChangeText={setValue}
      placeholder={placeholder}
      keyboardType="numeric"
      style={styles.input}
    />

  );

});

/* ======================================================
   CARD LEMBRETE
====================================================== */

const GraficoKm = ({ dados }) => {

  const pontos = useMemo(
    () => [...dados].slice(0, 10).reverse(),
    [dados]
  );

  const formatKmLabel = (v) => {
    if (v >= 1000) {
      const k = v / 1000;
      return k % 1 === 0 ? k + 'k' : k.toFixed(1) + 'k';
    }
    return v.toString();
  };

  if (pontos.length < 2) {
    return (
      <Text style={styles.graficoVazio}>
        Confirme a quilometragem mais vezes para ver o gráfico de evolução.
      </Text>
    );
  }

  const valores = pontos.map(p => parseInt(p.km) || 0);
  const minVal = Math.min(...valores);
  const maxVal = Math.max(...valores);
  const range = maxVal - minVal || 1;
  const BARS_H = 78;
  const MIN_BAR = 16;

  return (
    <View style={styles.graficoWrapper}>

      <Text style={styles.graficoTitulo}>Evolução do odômetro</Text>

      <View style={styles.graficoBarrasArea}>
        {pontos.map((p, i) => {
          const val = parseInt(p.km) || 0;
          const ratio = (val - minVal) / range;
          const barH = MIN_BAR + ratio * BARS_H;
          const isLast = i === pontos.length - 1;
          return (
            <View key={p.id} style={styles.graficoColuna}>
              <Text style={[styles.graficoKmTopo, isLast && styles.graficoKmTopoDestaque]}>
                {isLast ? formatKmLabel(val) : ' '}
              </Text>
              <View style={[
                styles.graficoBarra,
                { height: barH, backgroundColor: isLast ? '#2980b9' : '#90caf9' }
              ]} />
            </View>
          );
        })}
      </View>

      <View style={styles.graficoRotulos}>
        {pontos.map((p, i) => {
          const isFirst = i === 0;
          const isLast = i === pontos.length - 1;
          return (
            <Text
              key={p.id}
              style={[
                styles.graficoData,
                isLast && { color: '#2980b9', fontWeight: '700' }
              ]}
            >
              {(isFirst || isLast) ? p.data.slice(0, 5) : ''}
            </Text>
          );
        })}
      </View>

      {maxVal > minVal && (
        <Text style={styles.graficoDelta}>
          +{(maxVal - minVal).toLocaleString('pt-BR')} km nos últimos {pontos.length} registros
        </Text>
      )}

    </View>
  );
};

const CardLembrete = memo(({ lembretes }) => {

  if (!lembretes || lembretes.length === 0) return null;

  return (
    <View style={styles.lembreteContainer}>
      <View style={styles.lembreteTituloRow}>
        <MaterialCommunityIcons name="bell-alert" size={18} color="#fff" />
        <Text style={styles.lembreteTitulo}>  Lembretes de Manutenção</Text>
      </View>
      {lembretes.map((l, i) => (
        <View key={i} style={[styles.lembreteItem, { backgroundColor: l.vencido ? '#c0392b' : '#e67e22' }]}>
          <MaterialCommunityIcons
            name={l.vencido ? 'alert-circle' : 'clock-alert-outline'}
            size={16}
            color="#fff"
          />
          <View style={{ flex: 1, marginLeft: 8 }}>
            <Text style={styles.lembreteTexto}>
              {l.vencido ? '⚠ VENCIDO' : '🔔 PRÓXIMO'}: {l.nome}
            </Text>
            <Text style={styles.lembreteSubTexto}>
              {l.vencido
                ? `Passou ${Math.abs(l.restante).toLocaleString('pt-BR')} km do prazo (prev. ${parseInt(l.kmProxima).toLocaleString('pt-BR')} km)`
                : `Faltam ${l.restante.toLocaleString('pt-BR')} km (prev. ${parseInt(l.kmProxima).toLocaleString('pt-BR')} km)`
              }
            </Text>
            {l.dataEstimada && (
              <View style={styles.lembreteEstimativaRow}>
                <MaterialCommunityIcons name="calendar-clock" size={12} color="rgba(255,255,255,0.9)" />
                <Text style={styles.lembreteEstimativa}>
                  {' '}Estimativa: {l.dataEstimada}{'  ·  '}{l.avgKmDia} km/dia
                </Text>
              </View>
            )}
          </View>
        </View>
      ))}
    </View>
  );

});

/* ======================================================
   CARD HISTÓRICO
====================================================== */

const CardHistorico = memo(({ item, excluir }) => {

  return (

    <View style={styles.card}>

      <Text style={styles.cardTitulo}>
        {item.nome}
      </Text>

      <Text style={styles.cardTexto}>
        Data: {item.data}
      </Text>

      {/* ÓLEO */}
      {item.nome === 'Óleo' && (
        <>
          <Text style={styles.cardTexto}>
            KM Troca: {item.kmTroca}
          </Text>

          <Text style={styles.cardTexto}>
            Próxima Troca: {item.kmProxima}
          </Text>
        </>
      )}

      {/* FILTROS */}
      {item.nome === 'Filtros' && (
        <>
          <Text style={styles.cardTexto}>
            Filtro Óleo:
            {item.filtros.filtroOleo ? ' ✔' : ' ❌'}
          </Text>

          <Text style={styles.cardTexto}>
            Filtro Ar:
            {item.filtros.filtroAr ? ' ✔' : ' ❌'}
          </Text>

          <Text style={styles.cardTexto}>
            Ar Condicionado:
            {item.filtros.filtroArCondicionado ? ' ✔' : ' ❌'}
          </Text>
        </>
      )}

      {/* PNEUS */}
      {item.nome === 'Pneus' && (
        <>
          <Text style={styles.cardTexto}>
            DD: {item.pneus.dd ? '✔' : '❌'}
          </Text>

          <Text style={styles.cardTexto}>
            DE: {item.pneus.de ? '✔' : '❌'}
          </Text>

          <Text style={styles.cardTexto}>
            TD: {item.pneus.td ? '✔' : '❌'}
          </Text>

          <Text style={styles.cardTexto}>
            TE: {item.pneus.te ? '✔' : '❌'}
          </Text>
        </>
      )}

      {/* ALINHAMENTO */}
      {item.nome === 'Alinhamento e Balanceamento' && (
        <>
          <Text style={styles.cardTexto}>
            Alinhamento:
            {item.alinhamento ? ' ✔' : ' ❌'}
          </Text>

          <Text style={styles.cardTexto}>
            Balanceamento:
            {item.balanceamento ? ' ✔' : ' ❌'}
          </Text>

          <Text style={styles.cardTexto}>
            Rodízio:
            {' '}{item.rodizio}
          </Text>
        </>
      )}

      {/* BATERIA */}
      {item.nome === 'Bateria' && (
        <>
          <Text style={styles.cardTexto}>
            Trocada:
            {item.bateria.trocada ? ' ✔' : ' ❌'}
          </Text>

          <Text style={styles.cardTexto}>
            Voltagem:
            {' '}{item.bateria.volts}V
          </Text>
        </>
      )}

      {/* CORREIAS */}
      {item.nome === 'Correias' && (
        <>
          <Text style={styles.cardTexto}>
            Correia Dentada:
            {item.correias.dentada ? ' ✔' : ' ❌'}
          </Text>

          <Text style={styles.cardTexto}>
            Correia Alternador:
            {item.correias.alternador ? ' ✔' : ' ❌'}
          </Text>
        </>
      )}

      {/* NOTAS */}
      {item.notas ? (
        <Text style={styles.cardNotas}>📝 {item.notas}</Text>
      ) : null}

      {/* CUSTO */}
      {item.custo && item.custo !== '0' && (
        <Text style={styles.cardCusto}>
          💰 R$ {parseFloat(item.custo).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </Text>
      )}

      {/* EXCLUIR */}
      <TouchableOpacity
        style={styles.botaoExcluir}
        onPress={() => excluir(item.id)}
      >

        <Text style={styles.textoExcluir}>
          Excluir
        </Text>

      </TouchableOpacity>

    </View>

  );

});

/* ======================================================
   APP
====================================================== */

export default function App() {

  const [modalVisible, setModalVisible] = useState(false);

  const [itemSelecionado, setItemSelecionado] = useState(null);

  const [historico, setHistorico] = useState([]);

  const [kmAtual, setKmAtual] = useState('');

  const [kmInput, setKmInput] = useState('');

  const [kmModalVisible, setKmModalVisible] = useState(false);

  const [kmModalInput, setKmModalInput] = useState('');

  const [kmHistorico, setKmHistorico] = useState([]);

  const [kmHistoricoAberto, setKmHistoricoAberto] = useState(false);

  const [custo, setCusto] = useState('');

  const [notas, setNotas] = useState('');

  // ÓLEO
  const [oleo, setOleo] = useState({
    kmTroca: '',
    kmProxima: ''
  });

  // FILTROS
  const [filtros, setFiltros] = useState({
    filtroOleo: false,
    filtroAr: false,
    filtroArCondicionado: false
  });

  // PNEUS
  const [pneus, setPneus] = useState({
    dd: false,
    de: false,
    td: false,
    te: false
  });

  // ALINHAMENTO
  const [alinhamento, setAlinhamento] = useState({
    alinhamento: false,
    balanceamento: false,
    rodizio: 'Nenhum'
  });

  // BATERIA
  const [bateria, setBateria] = useState({
    trocada: false,
    volts: ''
  });

  // CORREIAS
  const [correias, setCorreias] = useState({
    dentada: false,
    alternador: false
  });

  /* ======================================================
     CARREGAR DADOS
  ====================================================== */

  useEffect(() => {

    async function carregarDados() {

      try {

        const dados =
          await AsyncStorage.getItem('historico');

        if (dados) {
          setHistorico(JSON.parse(dados));
        }

        const km = await AsyncStorage.getItem('kmAtual');
        if (km) {
          setKmAtual(km);
          setKmInput(km);
          setKmModalInput(km);
        }

        const kmHist = await AsyncStorage.getItem('kmHistorico');
        if (kmHist) {
          setKmHistorico(JSON.parse(kmHist));
        }

        setKmModalVisible(true);

      } catch (error) {

        console.log(error);

      }

    }

    carregarDados();

  }, []);

  /* ======================================================
     SALVAR STORAGE
  ====================================================== */

  useEffect(() => {

    async function salvarStorage() {

      try {

        await AsyncStorage.setItem(
          'historico',
          JSON.stringify(historico)
        );

      } catch (error) {

        console.log(error);

      }

    }

    salvarStorage();

  }, [historico]);

  /* ======================================================
     SALVAR KM ATUAL
  ====================================================== */

  const salvarKmAtual = useCallback(() => {

    const val = kmInput.trim();
    if (!val) return;
    setKmAtual(val);
    AsyncStorage.setItem('kmAtual', val).catch(console.log);

  }, [kmInput]);

  /* ======================================================
     CALCULAR LEMBRETES
  ====================================================== */

  const avgKmDia = React.useMemo(() => {
    if (kmHistorico.length < 2) return 0;
    const parseData = (str) => {
      const [d, m, y] = str.split('/').map(Number);
      return new Date(y, m - 1, d);
    };
    const entries = [...kmHistorico].reverse();
    const oldest = entries[0];
    const newest = entries[entries.length - 1];
    const kmGain = parseInt(newest.km) - parseInt(oldest.km);
    const msElapsed = parseData(newest.data) - parseData(oldest.data);
    const dias = msElapsed / (1000 * 60 * 60 * 24);
    if (dias > 0 && kmGain > 0) return kmGain / dias;
    return 0;
  }, [kmHistorico]);

  const lembretes = React.useMemo(() => {

    const kmNum = parseInt(kmAtual, 10);
    if (!kmAtual || isNaN(kmNum)) return [];

    const calcDataEstimada = (restanteKm) => {
      if (avgKmDia <= 0 || restanteKm <= 0) return null;
      const dias = Math.round(restanteKm / avgKmDia);
      const d = new Date();
      d.setDate(d.getDate() + dias);
      return (
        d.getDate().toString().padStart(2, '0') + '/' +
        (d.getMonth() + 1).toString().padStart(2, '0') + '/' +
        d.getFullYear()
      );
    };

    const result = [];

    const oleosComProxima = historico.filter(
      (h) => h.nome === 'Óleo' && h.kmProxima
    );

    if (oleosComProxima.length > 0) {
      const maisRecente = oleosComProxima[0];
      const proximaNum = parseInt(maisRecente.kmProxima, 10);
      if (!isNaN(proximaNum)) {
        const diferenca = proximaNum - kmNum;
        if (diferenca <= 1000) {
          result.push({
            nome: 'Troca de Óleo',
            kmProxima: maisRecente.kmProxima,
            restante: diferenca,
            vencido: diferenca <= 0,
            dataEstimada: calcDataEstimada(diferenca),
            avgKmDia: Math.round(avgKmDia)
          });
        }
      }
    }

    return result;

  }, [kmAtual, historico, avgKmDia]);

  /* ======================================================
     CONFIRMAR KM MODAL
  ====================================================== */

  const confirmarKmModal = useCallback(() => {
    const val = kmModalInput.trim();
    if (val) {
      setKmAtual(val);
      setKmInput(val);
      AsyncStorage.setItem('kmAtual', val).catch(console.log);

      const agora = new Date();
      const dataFormatada =
        agora.getDate().toString().padStart(2, '0') + '/' +
        (agora.getMonth() + 1).toString().padStart(2, '0') + '/' +
        agora.getFullYear();

      const novaEntrada = {
        id: Date.now().toString(),
        km: val,
        data: dataFormatada
      };

      setKmHistorico((prev) => {
        const atualizado = [novaEntrada, ...prev].slice(0, 50);
        AsyncStorage.setItem('kmHistorico', JSON.stringify(atualizado)).catch(console.log);
        return atualizado;
      });
    }
    setKmModalVisible(false);
  }, [kmModalInput]);

  /* ======================================================
     ABRIR ITEM
  ====================================================== */

  const abrirItem = useCallback((item) => {

    setItemSelecionado(item);

    setModalVisible(true);

  }, []);

  /* ======================================================
     LIMPAR
  ====================================================== */

  const limpar = useCallback(() => {

    setOleo({
      kmTroca: '',
      kmProxima: ''
    });

    setFiltros({
      filtroOleo: false,
      filtroAr: false,
      filtroArCondicionado: false
    });

    setPneus({
      dd: false,
      de: false,
      td: false,
      te: false
    });

    setAlinhamento({
      alinhamento: false,
      balanceamento: false,
      rodizio: 'Nenhum'
    });

    setBateria({
      trocada: false,
      volts: ''
    });

    setCorreias({
      dentada: false,
      alternador: false
    });

    setCusto('');

    setNotas('');

  }, []);

  /* ======================================================
     SALVAR
  ====================================================== */

  const salvar = useCallback(() => {

    if (!itemSelecionado) return;

    const data = new Date();

    const dataFormatada =
      data.getDate().toString().padStart(2, '0') + '/' +
      (data.getMonth() + 1).toString().padStart(2, '0') + '/' +
      data.getFullYear();

    let registro = {
      id: Date.now().toString(),
      nome: itemSelecionado.nome,
      data: dataFormatada,
      custo: custo.trim() || '0',
      notas: notas.trim()
    };

    // ÓLEO
    if (itemSelecionado.nome === 'Óleo') {

      registro = {
        ...registro,
        kmTroca: oleo.kmTroca,
        kmProxima: oleo.kmProxima
      };
    }

    // FILTROS
    else if (itemSelecionado.nome === 'Filtros') {

      registro = {
        ...registro,
        filtros
      };
    }

    // PNEUS
    else if (itemSelecionado.nome === 'Pneus') {

      registro = {
        ...registro,
        pneus
      };
    }

    // ALINHAMENTO
    else if (
      itemSelecionado.nome ===
      'Alinhamento e Balanceamento'
    ) {

      registro = {
        ...registro,
        ...alinhamento
      };
    }

    // BATERIA
    else if (itemSelecionado.nome === 'Bateria') {

      registro = {
        ...registro,
        bateria
      };
    }

    // CORREIAS
    else if (itemSelecionado.nome === 'Correias') {

      registro = {
        ...registro,
        correias
      };
    }

    setHistorico((prev) => [registro, ...prev]);

    limpar();

    setModalVisible(false);

  }, [
    itemSelecionado,
    oleo,
    filtros,
    pneus,
    alinhamento,
    bateria,
    correias,
    custo,
    notas,
    limpar
  ]);

  /* ======================================================
     EXCLUIR
  ====================================================== */

  const excluir = useCallback((id) => {

    Alert.alert(
      'Excluir',
      'Deseja remover este registro?',
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },

        {
          text: 'Excluir',
          onPress: () => {

            setHistorico((prev) =>
              prev.filter((item) => item.id !== id)
            );

          }
        }
      ]
    );

  }, []);

  /* ======================================================
     ÍCONES
  ====================================================== */

  const renderIcon = useCallback((item) => {

    if (
      item.biblioteca ===
      'MaterialCommunityIcons'
    ) {

      return (
        <MaterialCommunityIcons
          name={item.icone}
          size={42}
          color={item.cor}
        />
      );
    }

    return (
      <FontAwesome5
        name={item.icone}
        size={38}
        color={item.cor}
      />
    );

  }, []);

  /* ======================================================
     RENDER
  ====================================================== */

  return (

    <View style={styles.container}>

      <Text style={styles.titulo}>
        Meu Carro 🚗
      </Text>

      {/* KM ATUAL */}
      <View style={styles.kmContainer}>
        <MaterialCommunityIcons name="gauge" size={20} color="#2980b9" />
        <TextInput
          value={kmInput}
          onChangeText={setKmInput}
          placeholder="KM atual do carro"
          keyboardType="numeric"
          style={styles.kmInput}
          returnKeyType="done"
          onSubmitEditing={salvarKmAtual}
        />
        <TouchableOpacity style={styles.kmBotao} onPress={salvarKmAtual}>
          <Text style={styles.kmBotaoTexto}>OK</Text>
        </TouchableOpacity>
      </View>

      {/* LEMBRETES */}
      <CardLembrete lembretes={lembretes} />

      {/* MENU */}
      <FlatList
        data={itens}
        numColumns={3}
        keyExtractor={(item) => item.id}
        removeClippedSubviews={true}
        initialNumToRender={6}
        scrollEnabled={false}
        renderItem={({ item }) => (

          <TouchableOpacity
            style={styles.item}
            onPress={() => abrirItem(item)}
          >

            <View style={styles.iconeBox}>
              {renderIcon(item)}
            </View>

            <Text style={styles.nome}>
              {item.nome}
            </Text>

          </TouchableOpacity>

        )}
      />

      {/* HISTÓRICO */}
      <FlatList
        data={historico}
        keyExtractor={(item) => item.id}
        removeClippedSubviews={true}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
        ListHeaderComponent={
          historico.length > 0
            ? (
              <View>
                <View style={styles.totalContainer}>
                  <MaterialCommunityIcons name="cash-multiple" size={20} color="#27ae60" />
                  <Text style={styles.totalTexto}>
                    {'  '}Total gasto:{' '}
                    <Text style={styles.totalValor}>
                      R$ {historico
                        .reduce((sum, h) => sum + (parseFloat(h.custo) || 0), 0)
                        .toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </Text>
                  </Text>
                </View>
                <Text style={styles.historicoTitulo}>Histórico</Text>
              </View>
            )
            : null
        }
        ListEmptyComponent={
          <Text style={styles.historicoVazio}>
            Nenhum registro ainda. Toque em uma categoria acima para começar.
          </Text>
        }
        renderItem={({ item }) => (
          <CardHistorico
            item={item}
            excluir={excluir}
          />
        )}
      />

      {/* HISTÓRICO DE KM */}
      {kmHistorico.length > 0 && (
        <View style={styles.kmHistContainer}>
          <TouchableOpacity
            style={styles.kmHistHeader}
            onPress={() => setKmHistoricoAberto((v) => !v)}
          >
            <View style={styles.kmHistHeaderLeft}>
              <MaterialCommunityIcons name="chart-line" size={18} color="#2980b9" />
              <Text style={styles.kmHistTitulo}>  Histórico de KM</Text>
            </View>
            <MaterialCommunityIcons
              name={kmHistoricoAberto ? 'chevron-up' : 'chevron-down'}
              size={20}
              color="#2980b9"
            />
          </TouchableOpacity>

          {kmHistoricoAberto && (
            <>
              <GraficoKm dados={kmHistorico} />

              {kmHistorico.map((entry, i) => (
                <View key={entry.id} style={[styles.kmHistItem, i === 0 && styles.kmHistItemFirst]}>
                  <MaterialCommunityIcons
                    name="gauge"
                    size={16}
                    color={i === 0 ? '#2980b9' : '#aaa'}
                  />
                  <Text style={[styles.kmHistKm, i === 0 && styles.kmHistKmRecente]}>
                    {'  '}{parseInt(entry.km).toLocaleString('pt-BR')} km
                  </Text>
                  <Text style={styles.kmHistData}>{entry.data}</Text>
                </View>
              ))}
            </>
          )}
        </View>
      )}

      {/* MODAL KM BOAS-VINDAS */}
      <Modal
        visible={kmModalVisible}
        animationType="fade"
        transparent
      >
        <View style={styles.fundo}>
          <View style={styles.modal}>

            <View style={styles.kmModalIconRow}>
              <MaterialCommunityIcons name="gauge" size={32} color="#2980b9" />
            </View>

            <Text style={styles.kmModalTitulo}>Qual a quilometragem atual?</Text>
            <Text style={styles.kmModalSub}>Informe o KM do odômetro para calcular quanto falta para a próxima manutenção.</Text>

            <TextInput
              value={kmModalInput}
              onChangeText={setKmModalInput}
              placeholder="Ex: 52000"
              keyboardType="numeric"
              style={[styles.input, { marginTop: 16 }]}
              autoFocus
              returnKeyType="done"
              onSubmitEditing={confirmarKmModal}
            />

            <TouchableOpacity style={styles.botao} onPress={confirmarKmModal}>
              <Text style={styles.textoBotao}>Confirmar</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => setKmModalVisible(false)}>
              <Text style={styles.fechar}>Pular por agora</Text>
            </TouchableOpacity>

          </View>
        </View>
      </Modal>

      {/* MODAL */}
      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent
      >

        <View style={styles.fundo}>

          <View style={styles.modal}>

            {itemSelecionado && (
              <>

                <Text style={styles.tituloModal}>
                  {itemSelecionado.nome}
                </Text>

                {/* ÓLEO */}
                {itemSelecionado.nome === 'Óleo' && (
                  <>

                    <Text style={styles.sub}>
                      KM Troca
                    </Text>

                    <TextInputField
                      value={oleo.kmTroca}
                      setValue={(text) =>
                        setOleo({
                          ...oleo,
                          kmTroca: text
                        })
                      }
                      placeholder="Ex: 50000"
                    />

                    <Text style={styles.sub}>
                      Próxima Troca (KM)
                    </Text>

                    <TextInputField
                      value={oleo.kmProxima}
                      setValue={(text) =>
                        setOleo({
                          ...oleo,
                          kmProxima: text
                        })
                      }
                      placeholder="Ex: 55000"
                    />

                  </>
                )}

                {/* FILTROS */}
                {itemSelecionado.nome === 'Filtros' && (
                  <>

                    <TouchableOpacity
                      onPress={() =>
                        setFiltros({
                          ...filtros,
                          filtroOleo:
                          !filtros.filtroOleo
                        })
                      }
                    >

                      <Text style={styles.check}>
                        Filtro Óleo
                        {filtros.filtroOleo ? ' ✔' : ''}
                      </Text>

                    </TouchableOpacity>

                    <TouchableOpacity
                      onPress={() =>
                        setFiltros({
                          ...filtros,
                          filtroAr:
                          !filtros.filtroAr
                        })
                      }
                    >

                      <Text style={styles.check}>
                        Filtro Ar
                        {filtros.filtroAr ? ' ✔' : ''}
                      </Text>

                    </TouchableOpacity>

                    <TouchableOpacity
                      onPress={() =>
                        setFiltros({
                          ...filtros,
                          filtroArCondicionado:
                          !filtros.filtroArCondicionado
                        })
                      }
                    >

                      <Text style={styles.check}>
                        Ar Condicionado
                        {filtros.filtroArCondicionado ? ' ✔' : ''}
                      </Text>

                    </TouchableOpacity>

                  </>
                )}

                {/* PNEUS */}
                {itemSelecionado.nome === 'Pneus' && (
                  <>

                    {[
                      ['dd', 'Dianteiro Direito'],
                      ['de', 'Dianteiro Esquerdo'],
                      ['td', 'Traseiro Direito'],
                      ['te', 'Traseiro Esquerdo']
                    ].map(([key, label]) => (

                      <TouchableOpacity
                        key={key}
                        onPress={() =>
                          setPneus({
                            ...pneus,
                            [key]: !pneus[key]
                          })
                        }
                      >

                        <Text style={styles.check}>
                          {label}
                          {pneus[key] ? ' ✔' : ''}
                        </Text>

                      </TouchableOpacity>

                    ))}

                  </>
                )}

                {/* ALINHAMENTO */}
                {itemSelecionado.nome === 'Alinhamento e Balanceamento' && (
                  <>

                    <TouchableOpacity
                      onPress={() =>
                        setAlinhamento({
                          ...alinhamento,
                          alinhamento:
                          !alinhamento.alinhamento
                        })
                      }
                    >

                      <Text style={styles.check}>
                        Alinhamento
                        {alinhamento.alinhamento ? ' ✔' : ''}
                      </Text>

                    </TouchableOpacity>

                    <TouchableOpacity
                      onPress={() =>
                        setAlinhamento({
                          ...alinhamento,
                          balanceamento:
                          !alinhamento.balanceamento
                        })
                      }
                    >

                      <Text style={styles.check}>
                        Balanceamento
                        {alinhamento.balanceamento ? ' ✔' : ''}
                      </Text>

                    </TouchableOpacity>

                  </>
                )}

                {/* BATERIA */}
                {itemSelecionado.nome === 'Bateria' && (
                  <>

                    <TouchableOpacity
                      onPress={() =>
                        setBateria({
                          ...bateria,
                          trocada:
                          !bateria.trocada
                        })
                      }
                    >

                      <Text style={styles.check}>
                        Bateria Trocada
                        {bateria.trocada ? ' ✔' : ''}
                      </Text>

                    </TouchableOpacity>

                    <Text style={styles.sub}>
                      Voltagem
                    </Text>

                    <TextInputField
                      value={bateria.volts}
                      setValue={(text) =>
                        setBateria({
                          ...bateria,
                          volts: text
                        })
                      }
                      placeholder="Ex: 12.6"
                    />

                  </>
                )}

                {/* CORREIAS */}
                {itemSelecionado.nome === 'Correias' && (
                  <>

                    <TouchableOpacity
                      onPress={() =>
                        setCorreias({
                          ...correias,
                          dentada:
                          !correias.dentada
                        })
                      }
                    >

                      <Text style={styles.check}>
                        Correia Dentada
                        {correias.dentada ? ' ✔' : ''}
                      </Text>

                    </TouchableOpacity>

                    <TouchableOpacity
                      onPress={() =>
                        setCorreias({
                          ...correias,
                          alternador:
                          !correias.alternador
                        })
                      }
                    >

                      <Text style={styles.check}>
                        Correia Alternador
                        {correias.alternador ? ' ✔' : ''}
                      </Text>

                    </TouchableOpacity>

                  </>
                )}

                {/* NOTAS */}
                <Text style={styles.sub}>Observações</Text>
                <TextInput
                  value={notas}
                  onChangeText={setNotas}
                  placeholder="Ex: Troca feita na oficina do João"
                  style={[styles.input, styles.inputMultiline]}
                  multiline
                  numberOfLines={3}
                />

                {/* CUSTO */}
                <Text style={styles.sub}>Custo (R$)</Text>
                <TextInput
                  value={custo}
                  onChangeText={setCusto}
                  placeholder="Ex: 150,00"
                  keyboardType="numeric"
                  style={styles.input}
                />

                {/* BOTÃO */}
                <TouchableOpacity
                  style={styles.botao}
                  onPress={salvar}
                >

                  <Text style={styles.textoBotao}>
                    Salvar
                  </Text>

                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() =>
                    setModalVisible(false)
                  }
                >

                  <Text style={styles.fechar}>
                    Fechar
                  </Text>

                </TouchableOpacity>

              </>
            )}

          </View>

        </View>

      </Modal>

    </View>

  );

}

/* ======================================================
   STYLES
====================================================== */

const styles = StyleSheet.create({

  container: {
    flex: 1,
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#fff'
  },

  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 12
  },

  kmContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#eaf4fb',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#d0e8f5'
  },

  kmInput: {
    flex: 1,
    marginLeft: 8,
    fontSize: 15,
    color: '#333'
  },

  kmBotao: {
    backgroundColor: '#2980b9',
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 8
  },

  kmBotaoTexto: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 13
  },

  lembreteContainer: {
    backgroundColor: '#2c3e50',
    borderRadius: 12,
    padding: 12,
    marginBottom: 14
  },

  lembreteTituloRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8
  },

  lembreteTitulo: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14
  },

  lembreteItem: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 8,
    padding: 8,
    marginBottom: 4
  },

  lembreteTexto: {
    color: '#fff',
    fontSize: 13,
    fontWeight: '700'
  },

  lembreteSubTexto: {
    color: 'rgba(255,255,255,0.88)',
    fontSize: 12,
    marginTop: 2
  },

  lembreteEstimativaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 5,
    backgroundColor: 'rgba(0,0,0,0.15)',
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 4,
    alignSelf: 'flex-start'
  },

  lembreteEstimativa: {
    color: 'rgba(255,255,255,0.95)',
    fontSize: 11,
    fontWeight: '600'
  },

  kmModalIconRow: {
    alignItems: 'center',
    marginBottom: 8
  },

  kmModalTitulo: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#1a1a2e',
    marginBottom: 6
  },

  kmModalSub: {
    fontSize: 13,
    color: '#777',
    textAlign: 'center',
    lineHeight: 18
  },

  item: {
    flex: 1,
    margin: 6,
    backgroundColor: '#f5f6fa',
    borderRadius: 16,
    alignItems: 'center',
    padding: 14
  },

  iconeBox: {
    marginBottom: 8
  },

  nome: {
    fontSize: 11,
    textAlign: 'center',
    color: '#444',
    fontWeight: '600'
  },

  fundo: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end'
  },

  modal: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    paddingBottom: 40
  },

  tituloModal: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16
  },

  sub: {
    fontSize: 13,
    color: '#888',
    marginBottom: 4,
    marginTop: 8
  },

  check: {
    fontSize: 16,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
    color: '#333'
  },

  botao: {
    marginTop: 20,
    backgroundColor: '#2ecc71',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center'
  },

  textoBotao: {
    color: '#fff',
    fontWeight: 'bold'
  },

  fechar: {
    textAlign: 'center',
    marginTop: 10,
    color: '#888'
  },

  kmHistContainer: {
    backgroundColor: '#f0f7ff',
    borderRadius: 14,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#d0e8f5',
    overflow: 'hidden'
  },

  kmHistHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 14
  },

  kmHistHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center'
  },

  kmHistTitulo: {
    fontSize: 15,
    fontWeight: '700',
    color: '#2980b9'
  },

  kmHistItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: '#ddeef8'
  },

  kmHistItemFirst: {
    backgroundColor: '#e3f2fd'
  },

  kmHistKm: {
    flex: 1,
    fontSize: 14,
    color: '#555'
  },

  kmHistKmRecente: {
    color: '#2980b9',
    fontWeight: '700'
  },

  kmHistData: {
    fontSize: 12,
    color: '#999'
  },

  graficoWrapper: {
    paddingHorizontal: 12,
    paddingTop: 14,
    paddingBottom: 10,
    borderTopWidth: 1,
    borderTopColor: '#ddeef8'
  },

  graficoTitulo: {
    fontSize: 11,
    fontWeight: '700',
    color: '#90a4ae',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    marginBottom: 10
  },

  graficoBarrasArea: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    height: 110,
    paddingBottom: 0
  },

  graficoColuna: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end'
  },

  graficoKmTopo: {
    fontSize: 8,
    color: '#b0bec5',
    marginBottom: 3
  },

  graficoKmTopoDestaque: {
    fontSize: 10,
    color: '#2980b9',
    fontWeight: '800'
  },

  graficoBarra: {
    width: '65%',
    borderTopLeftRadius: 5,
    borderTopRightRadius: 5,
    minHeight: 16
  },

  graficoRotulos: {
    flexDirection: 'row',
    marginTop: 5
  },

  graficoData: {
    flex: 1,
    fontSize: 8,
    color: '#b0bec5',
    textAlign: 'center'
  },

  graficoDelta: {
    fontSize: 11,
    color: '#27ae60',
    fontWeight: '600',
    textAlign: 'center',
    marginTop: 8,
    marginBottom: 2
  },

  graficoVazio: {
    fontSize: 12,
    color: '#b0bec5',
    textAlign: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderTopWidth: 1,
    borderTopColor: '#ddeef8'
  },

  historicoTitulo: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#555',
    marginTop: 20,
    marginBottom: 10
  },

  historicoVazio: {
    textAlign: 'center',
    color: '#aaa',
    marginTop: 30,
    fontSize: 14,
    paddingHorizontal: 20
  },

  card: {
    backgroundColor: '#f5f6fa',
    padding: 15,
    borderRadius: 15,
    marginBottom: 10
  },

  cardTitulo: {
    fontSize: 18,
    fontWeight: 'bold'
  },

  cardTexto: {
    color: '#555',
    marginTop: 3
  },

  cardNotas: {
    color: '#666',
    fontStyle: 'italic',
    marginTop: 6,
    fontSize: 13
  },

  cardCusto: {
    color: '#27ae60',
    fontWeight: 'bold',
    marginTop: 6,
    fontSize: 14
  },

  totalContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#eafaf1',
    borderRadius: 12,
    padding: 12,
    marginTop: 20,
    marginBottom: 4,
    borderWidth: 1,
    borderColor: '#a9dfbf'
  },

  totalTexto: {
    fontSize: 15,
    color: '#333'
  },

  totalValor: {
    fontWeight: 'bold',
    color: '#27ae60'
  },

  input: {
    backgroundColor: '#f1f2f6',
    padding: 12,
    borderRadius: 10,
    marginBottom: 10,
    color: '#333'
  },

  inputMultiline: {
    height: 80,
    textAlignVertical: 'top'
  },

  botaoExcluir: {
    marginTop: 10,
    backgroundColor: '#e74c3c',
    padding: 10,
    borderRadius: 10,
    alignItems: 'center'
  },

  textoExcluir: {
    color: '#fff',
    fontWeight: 'bold'
  }

});
